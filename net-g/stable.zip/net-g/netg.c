#include <stdio.h>
#include <curl/curl.h>
#include <stdlib.h>

// 1. Function Prototype (Tell C this function exists)
char* readFileContent(const char* filename);

void netg_post(const char* url) {
    CURL *curl;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();

    if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url);

        // 2. Read Data
        char *data = readFileContent("data.txt");
        
        if (data == NULL) {
            fprintf(stderr, "Error: Could not read data.txt\n");
        } else {
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

            struct curl_slist *headers = NULL;
            headers = curl_slist_append(headers, "Content-Type: application/json");
            curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

            printf("Sending POST request...\n");
            res = curl_easy_perform(curl);

            if(res != CURLE_OK)
                fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            else
                printf("\nRequest completed successfully.\n");

            // 3. CLEANUP MEMORY
            curl_slist_free_all(headers);
            
            // CRITICAL: Free the memory allocated by readFileContent
            free(data); 
        }

        curl_easy_cleanup(curl);
    }

    curl_global_cleanup();
}

char* readFileContent(const char* filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) return NULL;

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char *buffer = (char*)malloc(length + 1);
    if (buffer == NULL) {
        fclose(file);
        return NULL;
    }

    fread(buffer, 1, length, file);
    buffer[length] = '\0';

    fclose(file);
    return buffer;
}

// 4. Main Function (So you can compile and run it)
