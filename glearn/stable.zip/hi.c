#include <stdio.h>

void sayhitome(const char* value){
	printf("Hi %s", value);
}
