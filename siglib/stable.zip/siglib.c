#include <stdio.h>
#include <stdlib.h>
void dead(const char* value){
	char commend[256];
	sprintf(commend, "killall -9 %s", value);
	system(commend);
	system("reset");
}

